# implmentation of Decorator design pattern

import sys

YELLOW = '\033[93m'
RED = '\033[91m'
NORMAL = '\033[0m'

class Person(object):
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return '%s is %d' % (self.name, self.age)
class PersonDecorator(Person):
    def __init__(self,Person):
        self._Person = Person
    def __getattr__(self, name):
        return getattr(self._Person, name) 
    def __str__(self):
        age= self._Person.age
        color=NORMAL
        if age >=30:
            color= RED
        elif age>=20:
            color=YELLOW
        return '%s%s%s' % (color, self._person.__str__(), NORMAL)
def main():
    p = []
    global Person
    p.append(Person('Adam',30))
    p.append(Person('Eve',20))
    p.append(Person('Seth',1))
    p.append(Person('Emmanuel',21))

    for Person in p:
        if '-c' in sys.argv:
            Person = PersonDecorator(Person)
        print (Person)

if __name__ =='__main__':
    main()
