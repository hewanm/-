public interface Visitor {
    public void visit(Manager manager);

    public void visit(Employee employee);

    public void visit(Freelancer freelancer);

}
