public class Manager extends Staff implements Visitable {
    private Project project;

    public Manager(Project project, String name){
        super(name);
        this.project=project;
    }

    public Project getProject() {
        return this.project;
    }

    public void  accept(Visitor visitor){
        visitor.visit(this);
    }
}
