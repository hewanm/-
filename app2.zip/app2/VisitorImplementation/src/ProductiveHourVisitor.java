import java.util.DoubleSummaryStatistics;

public class ProductiveHourVisitor implements Visitor {

    public ProductiveHourVisitor(){

    }

   private final DoubleSummaryStatistics stats = new DoubleSummaryStatistics();

    public DoubleSummaryStatistics getResult() {
        return stats;
    }

    public void visit(Employee employee){
        int sumDays = employee.getWorkedDays()+employee.getSickDays()+employee.getVacationDays();
        double normalizedDaySalary = employee.getMonthlySalary()/sumDays;
        double sickDaySalary = normalizedDaySalary*0.8;

        double realMonthSalary = sickDaySalary * employee.getSickDays()+normalizedDaySalary*(sumDays-employee.getSickDays());

        double hourSalary = realMonthSalary/sumDays/8;
        System.out.println("Employee "+employee.getName()+"  has  "+ hourSalary +"  hour salary");
        stats.accept(hourSalary);
    }

    public void visit(Freelancer freelancer){
        double hourSalary=freelancer.getHourlySalary();
        System.out.println("Freelancer "+freelancer.getName()+"  has  "+ hourSalary + "  hour salary");
        stats.accept(hourSalary);
    }

    public void visit (Manager manager){
        double hourSalary=manager.getProject().getProfit()*0.05/manager.getProject().getDuration()/8;
        System.out.println("Manager "+manager.getName()+"  has  "+ hourSalary + "  hour salary");
        stats.accept(hourSalary);
    }
}
